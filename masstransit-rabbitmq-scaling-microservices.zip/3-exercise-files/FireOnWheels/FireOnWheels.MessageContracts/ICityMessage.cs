﻿namespace FireOnWheels.Messaging
{
    public interface ICityMessage
    {
         
    }
}